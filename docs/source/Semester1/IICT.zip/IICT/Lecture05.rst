.. _s1-ict-l05:

Lecture 05
----------
| Class didn't happen so, no info here. Teacher was sick.