==========================
IICT (Introduction to ICT)
==========================

| This site is undergoing updates until the Semester finishes. Please refresh the page to make sure it's the latest version.
|
| To avoid copyright issues with FAST, none of their material will be uploaded here. I can however reference info from it, and upload and link files that don't belong to them.
|
| IICT is worth 1 Total Credit Hour.
|
| Outline for IICT:

*    10 Lab Tasks. Total Absolutes: 15
*    1 Assignment. Total Absolutes: 10
*    1 Presentation. Total Absolutes: 15
*    1 Project. Total Absolutes: 20
*    1 Final Exam. Total Absolutes: 40

| Grading Policy is Absolute Grading.

.. toctree::
   :caption: Lectures
   :maxdepth: 1
   :glob:


   
   *
