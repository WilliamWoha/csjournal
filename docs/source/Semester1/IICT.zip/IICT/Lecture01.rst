.. _s1-ict-l01:

Lecture 01
----------
Definitions and History:
^^^^^^^^^^^^^^^^^^^^^^^^
| The definitions of Computer, User, Data, Software and IT are discussed. Further, the Evolution of Computers from the first Analog Computers to the Electronic Computers of today is explored. This isn't rocket science.

Lab Work:
^^^^^^^^^
| The lab work consists of using 'Datum', a university-computer only program to log in to and access your files. After that, take a typing test from a pre-installed app and submit your scores. If you actually want to improve your speed though, search for the 'typeracer' or 'aoeu' tests on google (the latter doesn't have any grammar) and practice them, they're better.
