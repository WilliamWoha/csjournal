===============
Applied Physics
===============

| This site is undergoing updates until the Semester finishes. Please refresh the page to make sure it's the latest version.
|
| To avoid copyright issues with FAST, none of their material will be uploaded here. I can however reference info from it, and upload and link files that don't belong to them.
|
| Applied Physics is worth 3 Total Credit Hours.
|
| Outline for AP:

*    5 Assignments. Total Absolutes: 10
*    5 Quizzes. Total Absolutes: 10
*    1 Sessional-I. Total Absolutes: 15
*    1 Sessional-II. Total Absolutes: 15
*    1 Final Exam. Total Absolutes: 50

| Grading Policy is Absolute Grading.

| Textbook:

*    Fundamentals of Physics; 10th Edition by Halliday/Resnick/Walker

.. toctree::
   :caption: Lectures
   :maxdepth: 1
   :glob:


   
   *